# super_trunfo.c
Meu primeiro aplicativo.
