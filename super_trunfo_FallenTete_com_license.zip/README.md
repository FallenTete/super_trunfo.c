
# 🃏 Super Trunfo em C

Este é um jogo simples de **Super Trunfo** implementado em linguagem **C**. O jogador escolhe um atributo (força, velocidade ou inteligência) para competir com a carta do oponente. Existe uma carta especial chamada **Super Trunfo** que vence qualquer outra, exceto outro Super Trunfo.

---

## 🚀 Como compilar e executar

### ✅ Pré-requisitos
- Compilador C instalado:
  - **Windows**: [MinGW](https://sourceforge.net/projects/mingw)
  - **Linux/macOS**: GCC (geralmente já instalado)

---

### 🔧 Compilação

#### 🔹 Windows (cmd)
```bash
gcc super_trunfo.c -o super_trunfo.exe
super_trunfo
```

#### 🔹 Linux/macOS (terminal)
```bash
gcc super_trunfo.c -o super_trunfo
./super_trunfo
```

---

## 📦 Estrutura da Carta

Cada carta tem os seguintes atributos:
- `nome`: nome do personagem
- `forca`: poder físico
- `velocidade`: rapidez
- `inteligencia`: capacidade mental
- `superTrunfo`: indica se é a carta especial

---

## ✨ Exemplo de cartas
```text
Nome: Dragão
Força: 90
Velocidade: 60
Inteligência: 70

Nome: Deus do Trovão
Força: 99
Velocidade: 99
Inteligência: 99
⚡ Esta é uma carta SUPER TRUNFO!
```

---

## 🧠 Lógica do Jogo

- O jogador 1 escolhe um atributo.
- O programa compara esse atributo entre as duas cartas.
- Se uma das cartas for Super Trunfo, ela vence automaticamente (exceto contra outra Super Trunfo).
- O resultado (vitória, derrota ou empate) é mostrado no terminal.

---

## 📁 Arquivo principal

- `super_trunfo.c`: código-fonte principal do jogo

---

## 👨‍💻 Autor

Desenvolvido com 💡 por FallenTete

---

## 📜 Licença

Este projeto está licenciado sob a [MIT License](LICENSE).
