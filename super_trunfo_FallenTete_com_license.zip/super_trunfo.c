
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define NUM_CARTAS 6
#define NUM_ATRIBUTOS 3

typedef struct {
    char nome[30];
    int forca;
    int velocidade;
    int inteligencia;
    int superTrunfo; // 1 se for super trunfo, 0 se não
} Carta;

void mostrarCarta(Carta c) {
    printf("Nome: %s\n", c.nome);
    printf("Força: %d\n", c.forca);
    printf("Velocidade: %d\n", c.velocidade);
    printf("Inteligência: %d\n", c.inteligencia);
    if (c.superTrunfo)
        printf("⚡ Esta é uma carta SUPER TRUNFO!\n");
}

int compararAtributo(Carta c1, Carta c2, int atributo) {
    if (c1.superTrunfo && !c2.superTrunfo)
        return 1;
    if (!c1.superTrunfo && c2.superTrunfo)
        return -1;

    switch (atributo) {
        case 1: return c1.forca - c2.forca;
        case 2: return c1.velocidade - c2.velocidade;
        case 3: return c1.inteligencia - c2.inteligencia;
        default: return 0;
    }
}

int main() {
    srand(time(NULL));

    Carta baralho[NUM_CARTAS] = {
        {"Dragão", 90, 60, 70, 0},
        {"Unicórnio", 50, 80, 100, 0},
        {"Troll", 95, 40, 30, 0},
        {"Fênix", 70, 75, 85, 0},
        {"Cérbero", 85, 65, 60, 0},
        {"Deus do Trovão", 99, 99, 99, 1}
    };

    int indicesUsados[NUM_CARTAS] = {0};

    int i, indice;
    Carta jogador1, jogador2;

    for (i = 0; i < NUM_CARTAS; i++) indicesUsados[i] = 0;

    do {
        indice = rand() % NUM_CARTAS;
    } while (indicesUsados[indice]);
    jogador1 = baralho[indice];
    indicesUsados[indice] = 1;

    do {
        indice = rand() % NUM_CARTAS;
    } while (indicesUsados[indice]);
    jogador2 = baralho[indice];
    indicesUsados[indice] = 1;

    printf("==== Jogador 1 ====\n");
    mostrarCarta(jogador1);

    int escolha;
    printf("\nJogador 1, escolha um atributo para competir:\n");
    printf("1 - Força\n2 - Velocidade\n3 - Inteligência\n");
    printf("Digite o número do atributo: ");
    scanf("%d", &escolha);

    printf("\n==== Jogador 2 ====\n");
    mostrarCarta(jogador2);

    int resultado = compararAtributo(jogador1, jogador2, escolha);

    printf("\n===== Resultado =====\n");
    if (resultado > 0) {
        printf("Jogador 1 venceu!\n");
    } else if (resultado < 0) {
        printf("Jogador 2 venceu!\n");
    } else {
        printf("Empate!\n");
    }

    return 0;
}
