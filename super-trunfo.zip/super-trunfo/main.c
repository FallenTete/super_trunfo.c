#include <stdio.h>
#include <string.h>

typedef struct {
    char nome[50];
    int forca;
    int velocidade;
    int inteligencia;
} Carta;

void mostrarCarta(Carta c) {
    printf("Carta: %s\n", c.nome);
    printf("  Força: %d\n", c.forca);
    printf("  Velocidade: %d\n", c.velocidade);
    printf("  Inteligência: %d\n", c.inteligencia);
    printf("--------------------------\n");
}

int main() {
    Carta jogador1 = {"Dragão Flamejante", 90, 60, 70};
    Carta jogador2 = {"Cavaleiro Fantasma", 75, 80, 85};

    int escolha;

    printf("Bem-vindo ao Super Trunfo - FallenTete Edition!\n\n");

    printf("Carta do Jogador 1:\n");
    mostrarCarta(jogador1);

    printf("Escolha o atributo para competir:\n");
    printf("1 - Força\n2 - Velocidade\n3 - Inteligência\n");
    printf("Digite sua escolha (1-3): ");
    scanf("%d", &escolha);

    printf("\nCarta do Jogador 2:\n");
    mostrarCarta(jogador2);

    int valor1, valor2;

    switch (escolha) {
        case 1:
            valor1 = jogador1.forca;
            valor2 = jogador2.forca;
            break;
        case 2:
            valor1 = jogador1.velocidade;
            valor2 = jogador2.velocidade;
            break;
        case 3:
            valor1 = jogador1.inteligencia;
            valor2 = jogador2.inteligencia;
            break;
        default:
            printf("Escolha inválida.\n");
            return 1;
    }

    printf("\nResultado:\n");
    if (valor1 > valor2) {
        printf("Jogador 1 vence!\n");
    } else if (valor1 < valor2) {
        printf("Jogador 2 vence!\n");
    } else {
        printf("Empate!\n");
    }

    return 0;
}
