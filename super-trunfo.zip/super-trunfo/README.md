# 🃏 Super Trunfo em C - FallenTete Edition

Jogo simples do Super Trunfo feito em C para dois jogadores. Desenvolvido por **FallenTete** como desafio prático de programação.

## 🚀 Como jogar

1. Compile o jogo com `make` ou manualmente com `gcc`.
2. Execute o programa.
3. Escolha um atributo: **Força**, **Velocidade** ou **Inteligência**.
4. Compare com a carta do oponente.
5. Veja quem vence!

## 🛠️ Compilação

### Usando o Makefile:

```bash
make
./supertrunfo
```

### Manualmente:

```bash
gcc -o supertrunfo main.c
./supertrunfo
```

No Windows (com MinGW):

```bash
gcc -o supertrunfo.exe main.c
supertrunfo.exe
```

## 📁 Estrutura

- `main.c`: Código fonte do jogo.
- `Makefile`: Automatiza a compilação.
- `.gitignore`: Evita versionar arquivos binários.
- `README.md`: Este documento com instruções.

---

Feito com 💻 por [FallenTete](https://github.com/FallenTete)
