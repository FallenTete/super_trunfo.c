#!/bin/bash
echo "Inicializando repositório Git para FallenTete..."

git init
git branch -M master
git remote add origin https://github.com/FallenTete/super-trunfo.git
git add .
git commit -m "Versão inicial do Super Trunfo em C"
git push -u origin master
